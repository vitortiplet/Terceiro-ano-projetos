/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import javax.swing.JOptionPane;

/**
 *
 * @author vitor.ssantos36
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        String nome = JOptionPane.showInputDialog("Digite seu nome completo:");
        String cpf = JOptionPane.showInputDialog("Informe seu CPF");
        JOptionPane.showMessageDialog(null,"nome :" + nome + "\nCPF: " + cpf);
    }
    
}
