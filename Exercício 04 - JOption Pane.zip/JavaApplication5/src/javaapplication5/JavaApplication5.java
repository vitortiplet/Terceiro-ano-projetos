/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication5;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import javax.swing.JOptionPane;

/**
 *
 * @author vitor.ssantos36
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        String opcao = JOptionPane.showInputDialog(
            "Menu:\n" +
            "1 - Cadastrar Usuario\n" +
            "2 - Consultar Dados\n" +  
            "3 - Sair\n\n" +
            "Digite opção: "                 
                    );
        if (opcao.equals("1")) {
            JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
            
        }else if (opcao.equals("2")) {
            JOptionPane.showMessageDialog(null,"Consultando Dados...");
        }else if (opcao.equals ("3")){
            JOptionPane.showMessageDialog(null, "Saindo");
            
        }else{
            JOptionPane.showMessageDialog(null,"Opção inválida");
        }
            
    }
    
}
