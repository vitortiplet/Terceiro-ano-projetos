package aula.__.Conectar.com.banco.H2;

import javax.swing.JOptionPane;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
        ConfigurableApplicationContext context = new SpringApplicationBuilder(Application.class).headless(false).run(args);
        JOptionPane.showInputDialog(null,"meu Painel utilizando Spring Boot");
	}

}
